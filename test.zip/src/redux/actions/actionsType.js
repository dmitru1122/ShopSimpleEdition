export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const ADDITEAMPRICE = 'ADDITEMPRICE';
export const ADDITEAM = 'ADDITEAM';


export const addFilter = 'ADDFILTER';
export const deleteFilter = "DELETEFILTER";
export const JEANS = 'JEANS';