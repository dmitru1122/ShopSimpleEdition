import React from 'react';
import './buttons.css';

function ButtonSale(props) {
    return (
        <div className="button-sale">
        <a href="https://best.aliexpress.com/
        ?lan=en&aff_platform=portals-tool&sk=_dUuWSuf&aff_trace_key=2413790c1ea04b12a61ac90b8ab1292d-1591105586720-01565-_dUuWSuf&terminal_id=71f4ede4ac4f4385abc5529a0f9da65a&aff_request_id=2413790c1ea04b12a61ac90b8ab1292d-1591105586720-01565-_dUuWSuf"
        alt="All sale" title="All sale">Look at the model</a>
        </div>
    )

}

export default ButtonSale;