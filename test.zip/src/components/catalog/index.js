import React from 'react';

import CatalogMain from './main/main';
import './CatalogStyle.css';


import AddIteam from '../addIteams/index';


function Catalog () {
    return (
        <>
        <CatalogMain styleClass="white-style-background"/>
        </>
    )
}

export default Catalog;